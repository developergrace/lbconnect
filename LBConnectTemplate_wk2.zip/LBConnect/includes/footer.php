<footer>
    LBConnect &copy; 2020 - Made by the students of COSW30 Spring
  </footer>
</body>
</html>